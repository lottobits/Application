<?php 

$settings = array(
    "name" => "WorldCoin Casino",
    "currency" => "BTC",
    "url" => "http://worldcoincasino.com",
    "rate" => ".9",
    "altcoin" => "WorldCoin",
    "altcoinl" => "worldcoin",
    "identifier" => "altcoinrpc",
    "password" => "98sMMevZnMHnhgEjTEp3UXQNVHqjSBpn2vVfb3pLxCeZ",
    "port" => "8332",
    "altc" => "WDC",
    "altcl" => "wdc",
);

//$smarty = new Smarty;

require VIEWS.'/layout/layout.php';
