<?php

use Lottobits\Application\Model\Install\Lottery;

Lottery::create();