<?php

use Lottobits\Lottery\Draws\Sweepstakes;

Sweepstakes::execute();
