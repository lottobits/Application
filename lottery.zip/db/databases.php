<?php
return array(
    'database' => array(
        'games/lottery' => ROOT . '/db/lottery.sqlite3',
        'blocks' => ROOT.'/db/lottobits.sqlite3',
    )
);
